<div id="navigation" style="width:100%;height:10%;background-color:yellow;">导航栏</div>
<div id="downcontent" style="width:100%;height:90%;background-color: pink;">
	<div id="entry" style="width:20%;height:100%;background-color:green;float:left;"></div>
	<div id="content" style="width:80%;height:100%;background-color:silver;float:left;"></div>
</div>